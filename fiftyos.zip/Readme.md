-
Author : Scott Alan Barry ; #flushyourmeds #scottbarry ;
https://sourceforge.net/projects/fiftyos/files/
https://archive.org/details/ytfif/
Fifty OS is a FORK of Slitaz Linux in Six Sets. ;
Works on Older Computers uses 100 MB of RAM. ;
It is Open Source and has a BSD License. ;
This is the 2025 Edition of Slitaz Linux. ;
cat xaa xab xac xad xae xaf >fiftyos.iso ;
-
